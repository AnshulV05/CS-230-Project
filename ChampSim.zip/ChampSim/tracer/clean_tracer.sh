export PIN_ROOT=/champsim/pin_v3.17/
make clean
