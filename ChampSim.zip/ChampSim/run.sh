#!/bin/bash
./build_champsim.sh bimodal no no no no $1 1 $2
./run_champsim.sh bimodal-no-no-no-no-$1-1core-$2 30 30 134.xz
